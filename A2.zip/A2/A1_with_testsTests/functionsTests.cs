﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using A1_with_tests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1_with_tests.Tests
{
    [TestClass()]
    public class functionsTests
    {
        [TestMethod()]
        public void randomnumberTest()
        {
            var fun = new functions();
            var r = fun.randomnumber();
            Assert.IsTrue(r >= 1 && r <= 10);
            Assert.IsNotNull(r);
            Assert.IsFalse(r > 11);
        }

        [TestMethod()]
        public void daytimeTest()
        {
            var fun = new functions();
            string s = "2/16/2024";
            string c = fun.daytime();
            Assert.AreEqual(s, c);
            Assert.AreNotSame(c, fun.daytime());
        }

        [TestMethod()]
        public void randomdinosaurTest()
        {
            var fun = new functions();
            var r = fun.randomdinosaur();
            Assert.IsTrue(r>=0 && r<=9);
            Assert.IsFalse(r>10);
        }

        [TestMethod()]
        public void stringrandomTest()
        {
            var fun = new functions();
            var r = fun.stringrandom("sadnsadjnasjdnsajnd");
            Assert.IsTrue(!string.IsNullOrEmpty(r));
            Assert.IsInstanceOfType(r, typeof(string));
        }
    }
}